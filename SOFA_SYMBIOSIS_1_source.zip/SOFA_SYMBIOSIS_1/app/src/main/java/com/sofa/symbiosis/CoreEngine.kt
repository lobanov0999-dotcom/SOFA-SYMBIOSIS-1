package com.sofa.symbiosis

import kotlin.math.max

/** Pure local scheduler prototype. CORE-10 is a 10-state cycle, not a numeral base. */
object CoreEngine {
    data class Decision(val coreState: Int, val phase: Int, val density: Double,
                        val predictedDensity: Double, val strategy: String,
                        val nextThreshold: Double, val explanation: String)

    fun decide(coreState: Int, density: Double, previousEma: Double,
               sparseThreshold: Double = 0.28, denseThreshold: Double = 0.38): Decision {
        val d = density.coerceIn(0.0, 1.0)
        val ema = if (previousEma < 0.0) d else 0.65 * previousEma + 0.35 * d
        // Hysteresis avoids rapid switching around the crossover.
        val strategy = when {
            ema < sparseThreshold -> "EVENTS"
            ema > denseThreshold -> "FULL_SCAN"
            else -> "HOLD"
        }
        val next = (coreState + 1).mod(10)
        val phase = when (next.mod(3)) { 0 -> 3; 1 -> 6; else -> 9 }
        val explanation = when (strategy) {
            "EVENTS" -> "Низкая активность: обрабатывать только изменившиеся элементы."
            "FULL_SCAN" -> "Высокая активность: полный проход может быть дешевле."
            else -> "Пограничная нагрузка: сохранить предыдущую стратегию."
        }
        return Decision(next, phase, d, ema, strategy, denseThreshold, explanation)
    }

    fun ema(previous: Double, sample: Double): Double =
        if (previous < 0.0) sample.coerceIn(0.0, 1.0)
        else (0.65 * previous + 0.35 * sample).coerceIn(0.0, 1.0)
}
