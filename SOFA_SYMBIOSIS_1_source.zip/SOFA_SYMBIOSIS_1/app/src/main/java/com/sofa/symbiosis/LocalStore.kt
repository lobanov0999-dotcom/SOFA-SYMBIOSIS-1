package com.sofa.symbiosis

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class LocalStore(context: Context) : SQLiteOpenHelper(context, "sofa_symbiosis.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE journal (id INTEGER PRIMARY KEY AUTOINCREMENT, created_at INTEGER NOT NULL, kind TEXT NOT NULL, core_state INTEGER NOT NULL, phase INTEGER NOT NULL, density REAL NOT NULL, ema REAL NOT NULL, strategy TEXT NOT NULL, note TEXT NOT NULL)")
        db.execSQL("CREATE TABLE kv (key TEXT PRIMARY KEY, value TEXT NOT NULL)")
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) { }

    fun putValue(key: String, value: String) {
        val v = android.content.ContentValues().apply { put("key", key); put("value", value) }
        writableDatabase.insertWithOnConflict("kv", null, v, SQLiteDatabase.CONFLICT_REPLACE)
    }
    fun getValue(key: String, fallback: String): String {
        readableDatabase.rawQuery("SELECT value FROM kv WHERE key=?", arrayOf(key)).use { c ->
            if (c.moveToFirst()) return c.getString(0)
        }
        return fallback
    }

    fun saveCycle(state: Int, phase: Int, density: Double, ema: Double, strategy: String, note: String) {
        val v = android.content.ContentValues().apply {
            put("created_at", System.currentTimeMillis()); put("kind", "cycle")
            put("core_state", state); put("phase", phase); put("density", density)
            put("ema", ema); put("strategy", strategy); put("note", note)
        }
        writableDatabase.insert("journal", null, v)
    }

    fun saveNote(note: String) {
        val v = android.content.ContentValues().apply {
            put("created_at", System.currentTimeMillis()); put("kind", "note")
            put("core_state", 0); put("phase", 3); put("density", 0.0)
            put("ema", 0.0); put("strategy", "MANUAL"); put("note", note)
        }
        writableDatabase.insert("journal", null, v)
    }

    fun recent(limit: Int = 12): List<String> {
        val out = mutableListOf<String>()
        readableDatabase.rawQuery("SELECT created_at, kind, core_state, phase, density, strategy, note FROM journal ORDER BY id DESC LIMIT ?", arrayOf(limit.toString())).use { c ->
            while (c.moveToNext()) {
                val time = java.text.SimpleDateFormat("dd.MM HH:mm", java.util.Locale.getDefault()).format(java.util.Date(c.getLong(0)))
                out += "$time · ${c.getString(1)} · CORE ${c.getInt(2)} / ${c.getInt(3)} · ${(c.getDouble(4) * 100).toInt()}% · ${c.getString(5)}\n${c.getString(6)}"
            }
        }
        return out
    }

    fun exportText(): String {
        val rows = recent(10000)
        return "SOFA SYMBIOSIS 1 — local journal\nExported: ${java.util.Date()}\n\n" + rows.joinToString("\n\n---\n\n")
    }
}
