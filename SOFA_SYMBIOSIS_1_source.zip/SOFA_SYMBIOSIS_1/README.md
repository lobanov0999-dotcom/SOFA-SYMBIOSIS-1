# SOFA · SYMBIOSIS 1 — Android prototype 0.1

A local-first Android starter project for the Xiaomi 12 Pro. This is a **source project**, not an installed app or a compiled APK.

## Included in v0.1
- Native Android launcher activity (the installed app gets its own home-screen icon).
- Local SQLite journal for notes and CORE cycles.
- Persistent CORE state, EMA estimate, and selected strategy across app restarts.
- CORE-10 state cycle and 3/6/9 phase marker.
- A simple adaptive scheduler prototype with a hold band (hysteresis).
- Export/share of the local journal using Android's share sheet.
- No `INTERNET` permission: this build cannot connect to the internet.

## Important boundaries
- This is a prototype of task/state scheduling, not an AI model and not autonomous learning of model weights.
- The density slider is a synthetic input for testing the scheduler; it is not measuring Android system load.
- There is no background service in this version. It runs only while the app is open.
- The journal is stored in the app's private sandbox. Uninstalling the app may erase it; export backups periodically.
- No cloud sync, telemetry, hidden network traffic, or remote control is implemented.

## Build in Android Studio
1. Install Android Studio with Android SDK Platform 35 and a JDK supported by Android Gradle Plugin 8.7.3.
2. Open this folder (`SOFA_SYMBIOSIS_1`) as an existing project.
3. Allow Gradle sync, then connect the Xiaomi 12 Pro with USB debugging enabled or use an emulator.
4. Select the `app` run configuration and press Run.
5. After installation, the launcher icon/label **SOFA · SYMBIOSIS 1** appears in the app drawer; add it to the home screen.

## First test
1. Open the app.
2. Move the activity slider to 5–15% and run several cycles (EVENTS should usually be selected after EMA settles low).
3. Move it to 80–100% and run cycles (FULL_SCAN should be selected after EMA rises).
4. Add a note, close/reopen the app, and verify that the journal and CORE state persist.
5. Use “Экспортировать журнал” to share or save a text backup.

## Architecture
- `CoreEngine.kt`: pure decision logic (CORE-10, phase marker, EMA, hysteresis).
- `LocalStore.kt`: SQLite journal and persistent key/value state.
- `MainActivity.kt`: offline user interface.

## Next engineering steps
1. Add automated tests for the scheduler and state transitions.
2. Measure real Android device costs before claiming performance gains.
3. Add encrypted backup/export and an explicit restore flow.
4. Only after the local core is stable, design an optional, user-approved network connector.
5. If true background work is needed, add a transparent Android WorkManager job with visible controls and battery-aware scheduling.
