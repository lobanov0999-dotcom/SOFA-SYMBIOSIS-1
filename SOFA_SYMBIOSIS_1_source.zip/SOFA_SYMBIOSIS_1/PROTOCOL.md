# SYMBIOSIS v0.1 — working protocol

## State model
- CORE state: integer 0..9, transition `(state + 1) mod 10`.
- Phase marker: 3, 6, 9, selected by `nextState mod 3`.
- These are state labels, not a new CPU instruction set or numeral base.

## Adaptive policy
- Sample activity density in [0, 1].
- Smooth it with EMA: `ema = 0.65 * previous + 0.35 * sample`.
- Below 0.28: choose event-oriented processing.
- Above 0.38: choose full scan.
- Between thresholds: hold the previous strategy to reduce oscillation.

Thresholds are provisional and must be calibrated on measured workloads. The current UI feeds synthetic density into the policy; it does not yet run a real event queue or benchmark Android performance.

## Blind/minimal-disclosure principle
The local core stores only state, density, strategy, timestamp, and user-entered notes. No content is sent anywhere. If a future connector is added, it must be opt-in, show what data is sent, and use authenticated encrypted transport.
